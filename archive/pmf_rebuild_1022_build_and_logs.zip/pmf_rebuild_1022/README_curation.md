Curated from mfpvector_archive_1022.tgz and pmf_pull_1022.tgz (recompute PC, 2026-10-22; see README.md, MANIFEST.tsv,
ENVIRONMENT.txt). Removed for the repository copy: GROMACS mdrun/grompp logs (*.log except the pipeline and stage logs
under work_pmf/ and mfpvector/pmf_final/), run inputs *.tpr (regenerable from the archived .mdp/.gro/.top/.ndx with
gmx grompp), antechamber intermediates, *.pkl, backups. The kit scripts (kit/) are the same as code/pmf/ in this
repository. pull_series/ holds the per-window pullx/pullf time series. The complete archives are held by the authors.
